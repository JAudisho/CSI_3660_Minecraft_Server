#!/bin/bash

# Navigate to the server directory
cd /home/minecraftserver

# Start the Minecraft Forge server in the background
java -Xms1G -Xmx2G -jar forge-1.12.2-14.23.5.2859.jar nogui &

# Optional: Add a delay to give the server some time to start
sleep 30

# Display a message indicating that the server is running
echo "Minecraft Forge server is now running in the background."
