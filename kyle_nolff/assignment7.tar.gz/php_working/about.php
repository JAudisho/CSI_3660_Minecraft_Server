<?php include("includes/a_config.php");?>
<!DOCTYPE html>
<html>
<head>
	<?php include("includes/head-tag-contents.php");?>
</head>
<body>

<?php include("includes/design-top.php");?>
<?php include("includes/navigation.php");?>

<div class="container" id="main-content">
	<h2>About Us</h2>
	<p>The team members for our Milestone 2 project are: member1, member2, and member3</p>

</div>

<?php include("includes/footer.php");?>

</body>
</html>
